"""Test suite for XOAUTH2 Proxy v2.0"""
